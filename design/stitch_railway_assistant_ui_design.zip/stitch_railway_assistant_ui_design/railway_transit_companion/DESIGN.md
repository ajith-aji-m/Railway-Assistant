---
name: Railway Transit Companion
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#424655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#727787'
  outline-variant: '#c2c6d8'
  surface-tint: '#0057ce'
  primary: '#0057cd'
  on-primary: '#ffffff'
  primary-container: '#0d6efd'
  on-primary-container: '#ffffff'
  inverse-primary: '#b1c5ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#b91a24'
  on-tertiary: '#ffffff'
  tertiary-container: '#dd3739'
  on-tertiary-container: '#150001'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b1c5ff'
  on-primary-fixed: '#001946'
  on-primary-fixed-variant: '#00419e'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  metric-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 28px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

This design system delivers a rapid-glance, precision-focused transit companion designed for high-stress, mobile-on-the-go environments. Train journeys demand instantaneous cognitive parsing: commuters must ascertain platform allocations, running delays, speed metrics, and station milestones under direct sunlight or within crowded terminals.

The visual tone merges Modern Functionalism with subtle aerodynamic touches. It avoids heavy, distracting decor in favor of immaculate typography, high contrast information chunking, purposeful status colors, and generous tap targets. 

Key attributes:
- **Instant Glanceability:** Essential status data (train number, arrival time, delay indicator, platform badge) sits at the highest visual tier.
- **Calm Utility:** Pure crisp white containers against airy off-white canvases (#F8FAFC) minimize sensory clutter.
- **Tactile Trust:** Subtle border contours, soft directional drop shadows, and pill-shaped badges deliver confident physical boundaries.

## Colors

The color architecture is built around immediate functional semantics:

- **Primary Electric Blue (`#0D6EFD` / `#0066FF`):** Powers active states, interactive controls, live GPS trackers, station route nodes, and top-level action triggers.
- **Secondary Emerald Green (`#10B981` / `#16A34A`):** Exclusively signifies operational health—trains running on-schedule, confirmed platform availability, and positive timeline checkpoints.
- **Tertiary Crimson Coral (`#EF4444` / `#DC2626`):** Dedicated to critical variance—delays, platform shifts, cancellations, and overdue milestones.
- **Neutral Charcoal & Slate (`#0F172A`, `#334155`, `#64748B`):** Establishes an uncompromised hierarchy of legibility, preserving contrast against bright backgrounds.
- **Canvas & Surface Tier (`#F8FAFC` base, `#FFFFFF` card surface, `#F1F5F9` sub-tier & dividing rules):** Ensures clear separation between interactive blocks without harsh black boundaries.

Semantic status colors must never compete with decorative elements. Status tokens always pair an accessible text shade with a soft 10–12% opacity background pill for optimal contrast.

## Typography

Plus Jakarta Sans brings a contemporary geometric rhythm combined with wide apertures and clear numerals, essential for legibility when displaying 5-digit train numbers (e.g., `12675`), 24-hour timestamps (`06:42`), platform indices, and speed readouts.

Rules for numeric rendering:
- Use tabular figures (`font-variant-numeric: tabular-nums`) across all timestamps, train identifiers, speed metrics, and platform tags to guarantee precise vertical alignment within vertical schedule timelines.
- Key train identifier numbers leverage `label-md` or `headline-md` at `fontWeight: 700` in primary charcoal (`#0F172A`) to anchor each card.
- Platform labels and delay delta warnings utilize `label-md` in bold weights to prevent ambiguity.

## Layout & Spacing

The system implements a mobile-first fluid layout architecture anchored by strict 4px / 8px incremental grids:

- **Mobile Viewports (<640px):** Single-column stack with persistent top app bar / hero header, 16px (`1rem`) outer lateral margins, and 12px or 16px component gutters.
- **Tablet / Split View (640px–1024px):** Dual-pane orientation where map tracking lives in the right panel (60% width) and itinerary or list details occupy the left container (40% width).
- **Desktop Dashboards (>1024px):** Fixed max-width viewport constraints (max 1140px centered) with 24px outer margins and 24px grid gutters.

Density guidelines:
- List items inside schedule views must maintain a vertical padding of at least 14px to accommodate touch interactions without accidental clicks.
- Train progress paths use an indented 32px track margin on the left side to separate timeline dots and vertical connecting lines from text metadata.

## Elevation & Depth

Visual depth is achieved through layered tonal planes combined with ultra-soft ambient occlusion, avoiding muddy drop shadows:

- **Level 0 (Canvas Base):** `#F8FAFC` flat surface.
- **Level 1 (Card & Module Surface):** `#FFFFFF` fill with a composite border (`1px solid #E2E8F0` or `#F1F5F9`) and an ambient shadow: `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Interactive Floating Cards & Floating Modals):** Used for live tracking bottom sheets, speedometer overlays, and map control clusters: `box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Sticky Navbars & Drawers):** `#FFFFFF` with 85% opacity backdrop blur (`backdrop-filter: blur(12px)`) bordered by a `1px solid rgba(226, 232, 240, 0.8)` bottom border.

## Shapes

The design system uses a rounded geometry standard (`roundedness: 2`), reflecting the smooth contour of high-speed passenger rail coaches and modern transit architecture:

- **Primary Cards & Containers:** 16px (`rounded-2xl`) outer corners with 12px interior element padding.
- **Pills, Badges & Micro Status Indicators:** 9999px fully rounded capsules for delay metrics (`+7m`), status pills (`Running`, `On time`), and platform identifiers.
- **Action Buttons & Form Fields:** 12px to 14px (`rounded-xl`) corner radiuses to provide a comfortable, tactile feel.
- **Modal Sheets:** 24px top-left and top-right corner radiuses for pull-up station dashboards and itinerary previews.

## Components

### Buttons
- **Primary Action Button:** Solid `#0D6EFD` fill, white text, 48px height on mobile. Subtle gradient optional (`from #0D6EFD to #0056D2`). On hover/press: scales to `0.98` with `#0B5ED7`.
- **Secondary / Soft Button:** Light primary tint (`#EFF6FF`), text `#0D6EFD`, hover `#DBEAFE`.
- **Icon Buttons (Share, Center Map, Settings):** 40x40px or 44x44px circular or 12px rounded squares, filled with `#FFFFFF` or `#F1F5F9`, border `1px solid #E2E8F0`.

### Cards & Station Items
- **Train Item Card:** Pure white `#FFFFFF` background, 16px roundedness, `1px solid #F1F5F9` border. Divided into:
  - *Left column:* Leading live dot (green for on-time, amber/coral for delay), train number (`12675`), departure timestamp.
  - *Center column:* Train title (`Kovai Express`), platform tag (`Platform 3` in neutral slate badge).
  - *Right column:* Delay badge (`+7m` in coral red `#EF4444` or `On time` in emerald `#10B981`) paired with a right navigation chevron (`#94A3B8`).

### Status Badges & Pills
- **Running / On-Time:** Background `#ECFDF5`, text `#059669`, `rounded-full`, 4px 10px padding.
- **Delayed:** Background `#FEF2F2`, text `#DC2626`, `rounded-full`, 4px 10px padding.
- **Platform Badge:** Background `#F1F5F9`, text `#475569`, `rounded-md`, 2px 6px padding with 11px uppercase bold styling.

### Route Timeline & Stops Component
- **Node Indicators:**
  - *Departed Stop:* Solid green `#10B981` node connected by solid 2px green vertical line.
  - *Current Location:* Vibrant blue pulsating ring (`#0D6EFD` outer ring with white center dot).
  - *Upcoming Stop:* Neutral slate outline (`2px solid #CBD5E1`) connected by muted gray line (`#E2E8F0`).
- **Timeline Row:** Right-aligned departure/arrival clock times with delay status offset beneath.

### Search & Input Fields
- **Station Search Input:** 48px height, filled with `#F8FAFC`, surrounded by `1px solid #E2E8F0`. Leading search magnifying glass icon in `#64748B`. Focus state transitions to `#FFFFFF` background with `2px solid #0D6EFD` glow.
- **Filter Tabs (Arrivals / Departures):** Segmented pill switch bar with `#F1F5F9` track; active item features `#FFFFFF` card with soft elevation and `#0F172A` bold label.

### Interactive Live Map HUD
- **Floating Telemetry Card:** Floating card displaying current speed (`62 km/h`), nearest station, and GPS status pill. Pinned above bottom viewport with 16px margins.
- **Map Control Floating Action Buttons (FAB):** Zoom in/out, re-center on train, compass orientation grouped vertically in a floating glassmorphic pillar on the right flank.